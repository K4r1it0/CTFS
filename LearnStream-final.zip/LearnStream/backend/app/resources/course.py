from flask import request
from flask_restful import Resource
from app.models import Course, Video, User
from app import db
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
import uuid

class CourseResource(Resource):
    @jwt_required()
    def post(self):
        claims = get_jwt()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)

        # Check if the user is of type 'instructor'
        if claims.get('user_type') != 'instructor':
            return {'message': 'Only instructors can create courses'}, 403

        data = request.get_json()

        # Check if 'name' and 'description' parameters exist in the request data
        if 'name' not in data or 'description' not in data:
            return {'message': 'Missing required parameters'}, 400

        course_name = data.get('name')
        course_description = data.get('description')

        new_course = Course(id=str(uuid.uuid4()), name=course_name, instructor_id=current_user_id, description=course_description)
        db.session.add(new_course)
        db.session.commit()

        return {'message': 'Course created successfully', 'course_id': new_course.id}, 201
