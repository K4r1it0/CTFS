from flask import request
from flask_restful import Resource
from app.models import User
from flask_jwt_extended import jwt_required, get_jwt_identity
from flask_jwt_extended import create_access_token
from app import db, bcrypt
import uuid
import ujson

class UserRegistration(Resource):
    def post(self):
        data = ujson.loads(request.get_data())
        required_parameters = ['username', 'password', 'user_type', 'first_name', 'last_name', 'email']

        # Check if any required parameter is missing
        if any(param not in data for param in required_parameters):
            return {'message': 'Missing required parameter(s)'}, 400

        username = data['username']
        email = data['email']  # Add email to the variables
        password = data['password']
        user_type = data['user_type']
        first_name = data['first_name']
        last_name = data['last_name']

        # Check if the username or email already exists
        existing_user = User.query.filter_by(username=username).first()
        existing_email = User.query.filter_by(email=email).first()

        if existing_user:
            return {'message': 'Username already exists'}, 400
        if existing_email:
            return {'message': 'Email already exists'}, 400

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new_user = User(
            id=str(uuid.uuid4()),
            username=username,
            password=hashed_password,
            user_type=user_type,
            first_name=first_name,
            last_name=last_name,
            email=email
        )
        db.session.add(new_user)
        db.session.commit()
        return {'message': 'User registered successfully'}, 201
class UserLogin(Resource):
    def post(self):
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password, password):
            access_token = create_access_token(identity=user.id,additional_claims={'user_type': user.user_type,'username':user.username})

            return {'access_token': access_token}, 200
        else:
            return {'message': 'Invalid credentials'}, 401


class UserProfile(Resource):
    @jwt_required()
    def get(self):
        # Get the user's profile information
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user:
            return {'message': 'User not found'}, 404

        return {
            'id': user.id,
            'username': user.username,
            'user_type': user.user_type,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email
        }, 200

