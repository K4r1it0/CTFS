from app import db
import uuid  # Import the UUID library

class User(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=str(uuid.uuid4()))  # Use UUID as the primary key
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)
    first_name = db.Column(db.String(50), nullable=True)  # Add first name
    last_name = db.Column(db.String(50), nullable=True)   # Add last name
    email = db.Column(db.String(120), unique=True, nullable=True)  # Add email

    # Define the relationship between User and Course (courses created by the user)
    courses = db.relationship('Course', backref='instructor', lazy='dynamic')

    # Define the relationship between User and Video (videos uploaded by the user)
    videos = db.relationship('Video', backref='uploader', lazy='dynamic')


class Course(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=str(uuid.uuid4()))  # Use UUID as the primary key
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)  # Add a column for course description
    instructor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    # Define the relationship between Course and Video (videos included in the course)
    videos = db.relationship('Video', backref='course', lazy='dynamic')


class Video(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    path = db.Column(db.String(200), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    uploader_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
