from flask import Flask,send_from_directory,current_app,jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from flask_restful import Api
import secrets
import string
import os 

app = Flask(__name__)
jwt_secret_key = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(32))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['JWT_SECRET_KEY'] = jwt_secret_key
app.config['UPLOAD_FOLDER'] = 'static/videos'
app.config['JWT_FRESHNESS'] = False
app.config['PROPAGATE_EXCEPTIONS'] = True
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)
api = Api(app) 

@app.route('/videos/<path:filename>')
def get_video(filename):
    static_folder = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'])
    return send_from_directory(static_folder, filename)

from app.resources.user import UserRegistration, UserLogin, UserProfile


api.add_resource(UserRegistration, '/user/register')
api.add_resource(UserLogin, '/user/login')
api.add_resource(UserProfile, '/user/me')


from app.resources.course import CourseResource

api.add_resource(CourseResource, '/courses')

from app.resources.video import VideoResource

api.add_resource(VideoResource, '/courses/<string:course_id>/videos')

