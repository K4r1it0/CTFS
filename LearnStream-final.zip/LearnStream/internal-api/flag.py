from flask import Flask
import os

app = Flask(__name__)

@app.route('/flag')
def get_flag():
    flag = os.environ.get('FLAG')  # Read the flag from an environment variable named 'FLAG'
    if flag is not None:
        return flag
    else:
        return "Flag not found in environment variables"

if __name__ == '__main__':
    app.run(port=8989, host="0.0.0.0")
