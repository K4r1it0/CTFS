<?php
session_start();


function sendToAdmin($url){
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:60000');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "url=$url");
    $headers = array();
    $headers[] = 'Content-Type: application/x-www-form-urlencoded';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
}


$allowedTypes = [
   'image/png',
   'image/jpeg'
];

$allowedExtensions = [
  'png',
  'jpg'
];

if (!isset($_SESSION["randPath"]) or !isset($_FILES["screenshot"]) or !isset($_REQUEST["URL"]) or !filter_var($_REQUEST["URL"], FILTER_VALIDATE_URL)) {
    die("Validation error or data/session is missing.");
}

$filepath = $_FILES['screenshot']['tmp_name'];
$fileSize = filesize($filepath);
$filetype = $_FILES['screenshot']['type'];
$fileExtension = pathinfo($_FILES["screenshot"]["name"])['extension'];
$filename = pathinfo($_FILES["screenshot"]["name"])['filename'];

if ($fileSize === 0) {
    die("The file is empty.");
}

if ($fileSize > 3145728) { 

    die("The file is too large");
}

if (!in_array($filetype, $allowedTypes) or !in_array($fileExtension, $allowedExtensions)) {
    die("File not allowed.");
}

$targetDirectory = __DIR__ . "/uploads/" . $_SESSION["randPath"]; 

$newFilepath = $targetDirectory . "/" . htmlentities(basename($filename)) . "." . $fileExtension;

if (!copy($filepath, $newFilepath)) { 
    
    die("Can't move file. $newFilepath");
} 

if (str_starts_with($_REQUEST["URL"], 'http://channgleurl/uploads/')) {
    echo 'Your complaint is sent to the admin';
    sendToAdmin($_REQUEST["URL"]);

} else {

    echo 'URL is not whitelisted';
}
unlink($filepath); 
?>



