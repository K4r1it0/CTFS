from flask import Flask, request
app = Flask(__name__)

@app.route('/flag',methods=['POST'])
def index():
		return "Flaaaaaaaaaaaaaaaaaaaaaaag"

app.run(host='127.0.0.1', port=1337)
