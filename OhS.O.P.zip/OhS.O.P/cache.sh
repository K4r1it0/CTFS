while true;do sudo resolvectl flush-caches;done
