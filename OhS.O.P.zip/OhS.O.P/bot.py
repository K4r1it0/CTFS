from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options
from flask import Flask, request
app = Flask(__name__)
from flask import Flask
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
app = Flask(__name__)

URLS = []

def chrome(URL):
	options = Options()
	options.add_argument('--headless')
	options.add_argument('--no-sandbox')
	options.add_argument('--disable-dev-shm-usage')
	driver = webdriver.Chrome(options=options, executable_path='./chromedriver')
	driver.implicitly_wait(3000)
	driver.get(URL)
#	print(driver.get_log('browser'))


@app.route('/',methods=['POST'])
def index():
	URL = request.form['url']
	URLS.append(url)
	return "URL Added"


@app.route('/openurls',methods=['GET'])
def response():
	for url in URLS:
		chrome(URL)


app.run(host='127.0.0.1', port=60000)
