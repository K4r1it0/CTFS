 docker-compose up --build --force-recreate
