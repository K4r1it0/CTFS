import os
import cherrypy
from jinja2 import Environment, select_autoescape, Template

# Configure Jinja2 template environment
env = Environment(autoescape=select_autoescape(['html', 'xml']))
blacklisted = ["_","import","os"]

class MyServer:
    @cherrypy.expose
    def index(self):
        host_header = cherrypy.request.headers.get('Host', '')
        cherrypy.response.headers['X-Template-Engine'] = 'Jinja2'
        cherrypy.response.headers['Server'] = None
        for blacklist in blacklisted:
            if blacklist in host_header:
                return "Forbidden"
        template_string = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Welcome Page</title>
                <link rel="stylesheet" href="https://{host_header}/static/css/bootstrap.min.css">
            </head>
            <body>
                <div class="container h-100">
                    <div class="row h-100 justify-content-center align-items-center">
                        <h1>Welcome to theRFC</h1>
                    </div>
                </div>

                <script src="https://{host_header}/static/js/jquery-3.5.1.slim.min.js"></script>
                <script src="https://{host_header}/static/js/popper.min.js"></script>
                <script src="https://{host_header}/static/js/bootstrap.min.js"></script>
            </body>
            </html>
        """

        # Render the HTML template using Jinja2 render_template_string
        template = env.from_string(template_string)
        rendered_html = template.render(host=host_header)

        return rendered_html

if __name__ == '__main__':
    static_dir = os.path.join(os.path.abspath(os.getcwd()), 'static')

    # Configure CherryPy to serve static files
    config = {
        '/static': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': static_dir,
        }
    }
    cherrypy.server.socket_host = '0.0.0.0'
    cherrypy.quickstart(MyServer(),'/', config=config)
