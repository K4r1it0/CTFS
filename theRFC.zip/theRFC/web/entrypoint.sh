#!/bin/sh

# Check if the FLAG environment variable is set
if [ -n "$FLAG" ]; then
  echo "$FLAG" > /flag.txt
fi

su cyctf -c "exec python server.py"

# Start the actual service
#exec python server.py

